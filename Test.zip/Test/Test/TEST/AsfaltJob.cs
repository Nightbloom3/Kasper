﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TEST
{
    class AsfaltJob
    {

        private static int Count { get; set; } = 1;
        public int Nr { get; set; }
        public string Adresse { get; set; }
        public int PostNummer { get; set; }
        public string Bemærkninger { get; set; }

        public AsfaltJob(string adresse, int postNummer, string bemærkninger)
        {
            Nr = Count++;
            Adresse = adresse;
            PostNummer = postNummer;
            Bemærkninger = bemærkninger;
        }



    }
}
