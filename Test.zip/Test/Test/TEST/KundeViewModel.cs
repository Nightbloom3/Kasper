﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Windows.UI.Xaml.Navigation;
using Newtonsoft.Json.Bson;
using TEST.Annotations;

namespace TEST
{
    class KundeViewModel : INotifyPropertyChanged
    {
        
        private int _nr;
        public ObservableCollection<Kunder> kunder { get; set; }
        public int Nr

        {
            get => _nr;
            set { _nr = value; OnPropertyChanged(); }
        }
        public string FirmaNavn { get; set; }
        public string KontaktPerson { get; set; }
        public string KontaktPersonNummer { get; set; }
        public string KontakPersonEmail { get; set; }

        public ICommand AddCommand { get; set; }
        public ICommand SaveCommand { get; set; }

        public KundeViewModel()
        {
            kunder = new ObservableCollection<Kunder>
            {
                new Kunder("Pankas","Kasper Blom","8888888","KasperBlom@Mail.dk")
            };

            AddCommand = new RelayCommand(Add);
            SaveCommand = new RelayCommand(Save);
            HentKunder();


        }


        private void Add()
        {
            kunder.Add(new Kunder(FirmaNavn,KontaktPerson,KontaktPersonNummer,KontakPersonEmail));
            Nr = kunder.Count;
        }

        private void Save()
        {
            PersistencyService.SaveNotesAsJsonAsync(kunder);
        }

        public async void HentKunder()
        {
            var hentKunder = await PersistencyService.LoadNotesFromJsonAsync();
            int max = 0;
            if (hentKunder != null)
                foreach (var kunde in hentKunder)
                {
                    kunder.Add(kunde);
                    if (max < kunde.Nr) max = kunde.Nr;
                }

            Nr = ++max;
        }


        #region OnPropertyChanged       

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
