﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Windows.Devices.PointOfService;
using TEST.Annotations;

namespace TEST
{
    class JobListViewModel : INotifyPropertyChanged
    {
        private int ordreNr;

        public static ObservableCollection<TypeJobs> AlleJobs { get; set; }

        public int Nr
        {
            get => ordreNr;
            set { ordreNr = value; OnPropertyChanged(); }
        }

        public string Adresse { get; set; }
        public int PostNummer { get; set; }
        public string Bemærkninger { get; set; }
        public string Beskrivelse1 { get; set; }
        public string Beskrivelse2 { get; set; }
        public string Beskrivelse3 { get; set; }
        public int RegionNr { get; set; } = 303;

        public ICommand AddCommand { get; set; }
        public ICommand ClearCommand { get; set; }

        public JobListViewModel()
        {
            AlleJobs = new ObservableCollection<TypeJobs>
            {
                //new TypeJobs("Holbækvej 34", 4560, "Fræseren skal gøre det her", "Du skal gøre det her",
                //    "Please gør det her", "Det er vigtigt at i gør det her")
            };

            HentNoter();

            AddCommand = new RelayCommand(Add);
            ClearCommand = new RelayCommand(ClearAll);
        }



        private void Add()
        {
            AlleJobs.Add(new TypeJobs(Adresse,PostNummer,Beskrivelse1,Beskrivelse2,Beskrivelse3,Bemærkninger));
            Nr = AlleJobs.Count;
            PersistencyServiceJobs.SaveNotesAsJsonAsync(AlleJobs);
        }


        public async void HentNoter()
        {
            var hentJobs = await PersistencyServiceJobs.LoadJobsFromJsonAsync();
            int max = 0;
            if (hentJobs != null)
                foreach (var job in hentJobs)
                {
                    AlleJobs.Add(job);
                    if (max < job.OrdreNr ) max = job.OrdreNr; //Sætter kundeNr = max
                }

            //Sætter kundeNr til største
            Nr = ++max;
        }

        private void ClearAll()
        {
            AlleJobs.Clear();
        }










        #region PropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
