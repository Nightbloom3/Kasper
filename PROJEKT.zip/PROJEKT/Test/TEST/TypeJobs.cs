﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TEST
{
    class TypeJobs
    {

        private static int Count { get; set; } = 1;
        public int OrdreNr { get; set; }
        public int RegionNr { get; set; }
        public string Adresse { get; set; }
        public int PostNummer { get; set; }
        public string Bemærkninger { get; set; }
        public string Beskrivelse1 { get; set; }
        public string Beskrivelse2 { get; set; }
        public string Beskrivelse3 { get; set; }

        public TypeJobs(string adresse, int postnummer, string beskrivelse1, string beskrivelse2, string beskrivelse3, string bemærkninger)
        {
            OrdreNr = Count++;
            RegionNr = 303;
            Adresse = adresse;
            PostNummer = postnummer;
            Bemærkninger = bemærkninger;
            Beskrivelse1 = beskrivelse1;
            Beskrivelse2 = beskrivelse2;
            Beskrivelse3 = beskrivelse3;
        }



        public override string ToString()
        {
            return $"OrdreNr: {OrdreNr}\nAdresse: {Adresse}\nPostnummer: {PostNummer}\nBeskrivelse1: {Beskrivelse1}\nBeskrivelse2: {Beskrivelse2}\nBeskrivelse3: {Beskrivelse3}\nBemærkninger: {Bemærkninger}";
        }
    }
}
