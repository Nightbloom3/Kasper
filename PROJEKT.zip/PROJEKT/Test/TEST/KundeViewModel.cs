﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Windows.UI.Xaml.Navigation;
using Newtonsoft.Json.Bson;
using TEST.Annotations;

namespace TEST
{
    class KundeViewModel : INotifyPropertyChanged
    {
        
        private int _nr;
        public static ObservableCollection<Kunder> kunder { get; set; }
        public static ObservableCollection<TypeJobs> AlleJobs { get; set; }

        public int Nr

        {
            get => _nr;
            set { _nr = value; OnPropertyChanged(); }
        }
        public string FirmaNavn { get; set; }
        public string KontaktPerson { get; set; }
        public string KontaktPersonNummer { get; set; }
        public string KontakPersonEmail { get; set; }


        private int _ordreNr;


        public int OrdreNr
        {
            get => _ordreNr;
            set { _ordreNr = value; OnPropertyChanged(); }
        }

        public string Adresse { get; set; }
        public int PostNummer { get; set; }
        public string Bemærkninger { get; set; }
        public string Beskrivelse1 { get; set; }
        public string Beskrivelse2 { get; set; }
        public string Beskrivelse3 { get; set; }
        public int RegionNr { get; set; } = 303;

        #region Commands

        public ICommand ClearCommand { get; set; }
        public ICommand AddCustomerCommand { get; set; }
        public ICommand AddJobCommand { get; set; }
        public ICommand SaveCommand { get; set; }

        #endregion

        public KundeViewModel()
        {
            kunder = new ObservableCollection<Kunder>
            {
                //new Kunder("Pankas","Kasper Blom","8888888","KasperBlom@Mail.dk")
            };

            AlleJobs = new ObservableCollection<TypeJobs>
            { 

                new TypeJobs("asdhja",3453,"asjd","asd","asd","asd")

            };


            AddCustomerCommand = new RelayCommand(AddCustomer);
            HentKunder();
            HentNoter();
            AddJobCommand = new RelayCommand(AddJob);
        }



        //AddCustomer Command tilføjer og gemmer kunden i listen.
        private void AddCustomer()
        {
            kunder.Add(new Kunder(FirmaNavn,KontaktPerson,KontaktPersonNummer,KontakPersonEmail));
            Nr = kunder.Count;
            PersistencyServiceKunder.SaveNotesAsJsonAsync(kunder);
        }

        //Henter noterne
        public async void HentKunder()
        {
            var hentKunder = await PersistencyServiceKunder.LoadNotesFromJsonAsync();
            int max = 0;
            if (hentKunder != null)
                foreach (var kunde in hentKunder)
                {
                    kunder.Add(kunde);
                    if (max < kunde.Nr) max = kunde.Nr; //Sætter kundeNr = max
                }

            //Sætter kundeNr til største
            Nr = ++max;
        }

        private void AddJob()
        {
            AlleJobs.Add(new TypeJobs(Adresse, PostNummer, Beskrivelse1, Beskrivelse2, Beskrivelse3, Bemærkninger));
            OrdreNr = AlleJobs.Count;
            PersistencyServiceJobs.SaveNotesAsJsonAsync(AlleJobs);
        }

        public async void HentNoter()
        {
            var hentJobs = await PersistencyServiceJobs.LoadJobsFromJsonAsync();
            int max = 0;
            if (hentJobs != null)
                foreach (var job in hentJobs)
                {
                    AlleJobs.Add(job);
                    if (max < job.OrdreNr) max = job.OrdreNr; //Sætter kundeNr = max
                }

            //Sætter kundeNr til største
            OrdreNr = ++max;
        }



        #region OnPropertyChanged       

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
