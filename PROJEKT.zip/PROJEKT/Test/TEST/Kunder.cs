﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Navigation;

namespace TEST
{
    class Kunder
    {
        
        private static int Count { get; set; } = 1;
        public int Nr { get; set; }
        public string FirmaNavn { get; set; }
        public string KontaktPerson { get; set; }
        public string KontaktPersonNummer { get; set; }
        public string KontakPersonEmail { get; set; }

        public Kunder(string firmaNavn, string kontaktPerson, string kontaktPersonNummer, string kontakPersonEmail)
        {
            FirmaNavn = firmaNavn;
            KontaktPerson = kontaktPerson;
            KontaktPersonNummer = kontaktPersonNummer;
            KontakPersonEmail = kontakPersonEmail;
            Nr = Count++;
        }

        public override string ToString()
        {
            return $"KundeNR: {Nr}\nFirma: {FirmaNavn}\nNavn: {KontaktPerson}\nTelefonnummer: {KontaktPersonNummer}\nMail: {KontakPersonEmail}";
        }
    }
}
